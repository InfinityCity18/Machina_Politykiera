use crossterm::event::{KeyCode, KeyEventKind};
use log::error;
use std::{error::Error, io, result::Result, sync::mpsc};

pub fn handle_input_events(tx: mpsc::Sender<Event>) {
    loop {
        match crossterm::event::read() {
            Ok(crossterm::event::Event::Key(key_event)) => match tx.send(Event::Key(key_event)) {
                Ok(_) => (),
                Err(e) => error!("Error sending key event: {}", e),
            },
            Err(e) => error!("Error reading input event: {}", e),
            _ => (),
        }
    }
}

pub enum Event {
    Key(crossterm::event::KeyEvent),
    Title(String),
    ListsRefresh,
}

#[derive(Clone)]
pub enum Focus {
    ProcessListWindow,
    MemoryListWindow,
    MemoryEditorWindow,
    LoggerWindow,
    ValueInputField,
    NewValueInputField,
}

use self::Event::*;
use self::Focus::*;
use crate::app::App;

impl App<'_> {
    pub fn handle_events(&mut self, rx: &mpsc::Receiver<Event>) -> Result<(), Box<dyn Error>> {
        match rx.recv() {
            Ok(Key(key_event)) => self.handle_key_event(key_event)?,
            Ok(Title(text)) => self.title_text = text,
            Ok(ListsRefresh) => {
                self.process_list.update();
                self.memory_scanner.update_list();
                self.memory_editor.update();
            }
            Err(e) => todo!("Error receiving event: {}", e),
        }
        Ok(())
    }

    fn handle_key_event(&mut self, key_event: crossterm::event::KeyEvent) -> io::Result<()> {
        if key_event.kind == KeyEventKind::Press {
            match (key_event.code, self.focus_window.clone()) {
                // esc resets
                (KeyCode::Esc, _) => self.set_focus(ProcessListWindow),

                // input
                (KeyCode::Enter, ValueInputField) => self.set_focus(ProcessListWindow),
                (_, ValueInputField) => self.scan_value_field.handle_key_event(key_event),
                (_, NewValueInputField) => self.handle_new_value_key_event(key_event),

                // when not inputing - switching focus/exiting
                (KeyCode::Char('q'), _) => self.exit = true,
                (KeyCode::Char('v'), _) => self.set_focus(ValueInputField),
                (KeyCode::Char('e'), _) => self.set_focus(MemoryEditorWindow),
                (KeyCode::Char('p'), _) => self.set_focus(ProcessListWindow),
                (KeyCode::Char('m'), _) => self.set_focus(MemoryListWindow),
                (KeyCode::Char('l'), _) => self.set_focus(LoggerWindow),
                (KeyCode::Char('t'), _) => self.scan_type_selector.cycle_type(),
                (KeyCode::Char('f'), _) => self.perform_scan(true), // first scan
                (KeyCode::Char('n'), _) => self.perform_scan(false), // next scan

                // controls other than chars depend on window focus
                (_, ProcessListWindow) => self.handle_process_list_key_event(key_event),
                (_, MemoryListWindow) => self.handle_memory_list_key_event(key_event),
                (_, MemoryEditorWindow) => self.handle_memory_edit_key_event(key_event),
                (_, LoggerWindow) => self.handle_logger_key_event(key_event),
            }
        }
        Ok(())
    }

    fn set_focus(&mut self, target: Focus) {
        // actions to perform after losing focus of a window
        match self.focus_window {
            ValueInputField => self.scan_value_field.selected = false,
            NewValueInputField => self.new_value_field.selected = false,
            _ => (),
        }

        // actions to perform on gaining focus of a window
        match target {
            ValueInputField => self.scan_value_field.selected = true,
            NewValueInputField => self.new_value_field.selected = true,
            _ => (),
        }

        self.focus_window = target;
    }

    fn handle_process_list_key_event(&mut self, key_event: crossterm::event::KeyEvent) {
        match key_event.code {
            KeyCode::Up => self.process_list.widget_state.select_previous(),
            KeyCode::Down => self.process_list.widget_state.select_next(),
            KeyCode::Enter => self.change_process_to_selected(),
            _ => (),
        }
    }

    fn handle_memory_list_key_event(&mut self, key_event: crossterm::event::KeyEvent) {
        match key_event.code {
            KeyCode::Up => self.memory_scanner.widget_state.select_previous(),
            KeyCode::Down => self.memory_scanner.widget_state.select_next(),
            KeyCode::Enter => match self.memory_scanner.get_selected() {
                Some(addr) => self.memory_editor.pin_address(addr),
                None => (),
            },
            _ => (),
        }
    }

    fn handle_memory_edit_key_event(&mut self, key_event: crossterm::event::KeyEvent) {
        match key_event.code {
            KeyCode::Up => self.memory_editor.widget_state.select_previous(),
            KeyCode::Down => self.memory_editor.widget_state.select_next(),
            KeyCode::Char('u') => self.memory_editor.unpin_selected(),
            KeyCode::Enter => self.set_focus(NewValueInputField),
            _ => (),
        }
    }

    fn handle_logger_key_event(&mut self, key_event: crossterm::event::KeyEvent) {
        match key_event.code {
            KeyCode::Up => self.logger.scroll_up(),
            KeyCode::Down => self.logger.scroll_down(),
            _ => (),
        }
    }

    fn handle_new_value_key_event(&mut self, key_event: crossterm::event::KeyEvent) {
        match key_event.code {
            KeyCode::Enter => self.edit_selected_value(),
            _ => self.new_value_field.handle_key_event(key_event),
        }
    }
}
